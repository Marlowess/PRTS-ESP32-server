DELIMITER //
  CREATE PROCEDURE boilerplate_proc()
    BEGIN
    SELECT CONCAT('Hello,', 'World!');
    END; //
DELIMITER ;

