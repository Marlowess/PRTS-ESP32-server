CALL boilerplate_proc();
