DROP PROCEDURE IF EXISTS boilerplate_proc;


